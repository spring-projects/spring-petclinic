import jetbrains.buildServer.configs.kotlin.*
import jetbrains.buildServer.configs.kotlin.buildFeatures.perfmon
import jetbrains.buildServer.configs.kotlin.buildSteps.maven
import jetbrains.buildServer.configs.kotlin.projectFeatures.dockerRegistry
import jetbrains.buildServer.configs.kotlin.projectFeatures.youtrack
import jetbrains.buildServer.configs.kotlin.triggers.vcs
import jetbrains.buildServer.configs.kotlin.vcs.GitVcsRoot

/*
The settings script is an entry point for defining a TeamCity
project hierarchy. The script should contain a single call to the
project() function with a Project instance or an init function as
an argument.

VcsRoots, BuildTypes, Templates, and subprojects can be
registered inside the project using the vcsRoot(), buildType(),
template(), and subProject() methods respectively.

To debug settings scripts in command-line, run the

    mvnDebug org.jetbrains.teamcity:teamcity-configs-maven-plugin:generate

command and attach your debugger to the port 8000.

To debug in IntelliJ Idea, open the 'Maven Projects' tool window (View
-> Tool Windows -> Maven Projects), find the generate task node
(Plugins -> teamcity-configs -> teamcity-configs:generate), the
'Debug' option is available in the context menu for the task.
*/

version = "2024.03"

project {

    vcsRoot(HttpsGithubComM4thomaSpringPetclinicGitRefsHeadsMain)

    buildType(Build)

    features {
        dockerRegistry {
            id = "PROJECT_EXT_2"
            name = "Docker Registry"
            userName = "m4thoma"
            password = "zxx668c72bb4c3cb18cdf7014dc20a84664afa5668060800000"
        }
        youtrack {
            id = "PROJECT_EXT_3"
            displayName = "Youtrack-tw20"
            host = "https://yt.tw20.de"
            userName = ""
            password = ""
            projectExtIds = "TSP"
            accessToken = "zxxfc7194003e333d010f46b9ca4a015446b49eec07e4e0cae0215067e84e7625aa003b2c44fdb2bc07da44a5849e09fe12dc3892795fbba3b8"
        }
    }
}

object Build : BuildType({
    name = "Build"

    vcs {
        root(HttpsGithubComM4thomaSpringPetclinicGitRefsHeadsMain)
    }

    steps {
        maven {
            id = "Maven2"
            goals = "clean test"
            runnerArgs = "-Dmaven.test.failure.ignore=true"
        }
    }

    triggers {
        vcs {
        }
    }

    features {
        perfmon {
        }
    }
})

object HttpsGithubComM4thomaSpringPetclinicGitRefsHeadsMain : GitVcsRoot({
    name = "https://github.com/m4thoma/spring-petclinic.git#refs/heads/main"
    url = "https://github.com/m4thoma/spring-petclinic.git"
    branch = "refs/heads/main"
    branchSpec = "refs/heads/*"
    authMethod = password {
        userName = "m4thoma"
        password = "zxx157916a434d5e1125db4c6ec32cd5b65617c315300f2e1ed"
    }
})
