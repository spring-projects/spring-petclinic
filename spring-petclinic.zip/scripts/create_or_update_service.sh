#!/bin/bash

ln -s -f /target/spring-petclinic-2.4.2.jar /etc/init.d/cdk-app