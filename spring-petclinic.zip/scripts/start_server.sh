#!/bin/bash

service cdk-app start