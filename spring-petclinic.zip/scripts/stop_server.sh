#!/bin/bash

service cdk-app stop
exit 0